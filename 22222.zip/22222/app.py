from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

# Пример пользователей с логинами и паролями

users = {
    'admin': '1234',  # Администратор
    'user': '1234'    # Обычный пользователь
}


@app.route('/')
def login1():
    return render_template('login.html')

@app.route('/', methods=['POST'])
def login():
    username = request.form['username']
    password = request.form['password']

    # Проверка логина и пароля
    if username in users and users[username] == password:
        if username == 'admin':
            return redirect(url_for('dashboard'))  # Для администратора
        else:
            return redirect(url_for('main'))  # Для обычного пользователя
    else:
        return 'Неверный логин или пароль', 401  # Ошибка при неверных данных

# Страница администратора
@app.route('/dashboard')
def dashboard():
    return render_template('dashboard.html')  # Панель администратора

# Страница обычного пользователя
@app.route('/main')
def main():
    return render_template('index.html')  # Главная страница для обычного пользователя

@app.route('/news')
def news():
    return render_template('news.html')


@app.route('/')
def admin():
    return render_template('dashboard.html')

@app.route('/index')
def index():
    return render_template('index.html')

@app.route('/services')
def services():
    return render_template('services.html')



if __name__ == '__main__':
    app.run(debug=True)
