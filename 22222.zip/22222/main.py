import os
import requests

# URL изображения
url = "https://yanva.ru/wp-content/uploads/2023/12/6u546u456rp-150x150.jpg"
# Локальный путь для сохранения
save_path = "static/images/rabotniki.jpg"

# Проверяем, существует ли папка 'images', если нет — создаем её
os.makedirs(os.path.dirname(save_path), exist_ok=True)

# Скачиваем изображение
response = requests.get(url)
if response.status_code == 200:
    with open(save_path, 'wb') as file:
        file.write(response.content)
    print(f"Изображение успешно сохранено в {save_path}")
else:
    print(f"Ошибка при загрузке изображения: {response.status_code}")
